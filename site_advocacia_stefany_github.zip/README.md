# Site — Stéfany Eduarda R. Rosa

Site institucional de Advocacia e Consultoria Jurídica.

## Arquivos
- `index.html` — página completa
- `logo.png` — símbolo extraído da imagem enviada

## Publicar no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie `index.html` e `logo.png` para a raiz do repositório.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde a publicação.

O botão de WhatsApp já está configurado para o número `(34) 9135-9436`.
